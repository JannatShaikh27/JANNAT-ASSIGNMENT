let why_we_best_section=document.querySelectorAll('.why_we_best ul>li')
let why_we_best_img=document.querySelector('.section-3 img')
let carousel_item_img=document.querySelectorAll('.carousel-item img')
// console.log(why_we_best_section,why_we_best_img)
console.log(carousel_item_img)

let images_array=[
    'https://images.unsplash.com/photo-1627308594190-a057cd4bfac8?q=80&w=1936&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    'https://images.unsplash.com/photo-1559181567-c3190ca9959b?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8RnJ1aXRzfGVufDB8MXwwfHx8Mg%3D%3D',
    'https://images.unsplash.com/photo-1601004890684-d8cbf643f5f2?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OHx8RnJ1aXRzfGVufDB8MXwwfHx8Mg%3D%3D'
]

why_we_best_section.forEach((elem,i)=>{
    elem.addEventListener('click',(e)=>{
        why_we_best_section.forEach(elem2=>{
        elem2.classList.remove('active')

        })
        elem.classList.add('active')
        why_we_best_img.src=images_array[i]

    })
})

carousel_item_img.forEach(elem=>{
    elem.addEventListener('mouseover',()=>{
        elem.classList.remove('d-block')
        elem.classList.add('d-none')
        elem.nextElementSibling.classList.remove('d-none')
        elem.nextElementSibling.classList.add('d-flex')
    })
    elem.addEventListener('mouseout',()=>{
        elem.classList.remove('d-none')
        elem.classList.add('d-block')
        elem.nextElementSibling.classList.remove('d-flex')
        elem.nextElementSibling.classList.add('d-none')
    })
})

